from fastapi import FastAPI
from pydantic import BaseModel
import pickle

app = FastAPI(title="Credit Risk API")

with open("model.pkl", "rb") as f:
    model, imputer = pickle.load(f)


class Client(BaseModel):
    credit_utilisation: float
    age: int
    debt_ratio: float
    income: float
    credit_lines: int

clients_db = []

# Ajouter client
@app.post("/clients/")
def add_client(client: Client):
    clients_db.append(client)
    return {"message": "Client ajouté"}

# Voir tous les clients
@app.get("/clients/")
def get_clients():
    return clients_db

# Voir un client
@app.get("/clients/{id}")
def get_client(id: int):
    if id < len(clients_db):
        return clients_db[id]
    return {"error": "Client non trouvé"}


# Nombre total de clients
@app.get("/kpi/total_clients")
def total_clients():
    return {"total": len(clients_db)}

# Revenu moyen
@app.get("/kpi/avg_income")
def avg_income():
    if len(clients_db) == 0:
        return {"avg_income": 0}

    avg = sum(c.income for c in clients_db) / len(clients_db)
    return {"avg_income": avg}

# Clients à risque (règle simple)
@app.get("/kpi/risky_clients")
def risky_clients():
    risky = [
        c for c in clients_db
        if c.debt_ratio > 0.5 or c.income < 2000
    ]
    return {"risky_clients": len(risky)}

# Taux de défaut (basé sur ML)
@app.get("/kpi/default_rate")
def default_rate():
    if len(clients_db) == 0:
        return {"default_rate": 0}

    predictions = []

    for c in clients_db:
        data = [[
            c.credit_utilisation,
            c.age,
            c.debt_ratio,
            c.income,
            c.credit_lines
        ]]

        data = imputer.transform(data)
        pred = model.predict(data)[0]

        predictions.append(pred)

    rate = sum(predictions) / len(predictions)

    return {"default_rate": rate}



@app.post("/predict")
def predict(client: Client):

    data = [[
        client.credit_utilisation,
        client.age,
        client.debt_ratio,
        client.income,
        client.credit_lines
    ]]

    data = imputer.transform(data)
    pred = model.predict(data)[0]

    return {
        "prediction": "Refusé" if pred == 1 else "Accepté"
    }