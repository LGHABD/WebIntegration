import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.impute import SimpleImputer
import pickle
import os
print(os.getcwd())
df = pd.read_csv("GiveMeSomeCredit-training.csv")

# Supprimer colonne inutile si existe
df = df.drop(columns=["Unnamed: 0"], errors="ignore")

y = df["SeriousDlqin2yrs"]

X = df[[
    "RevolvingUtilizationOfUnsecuredLines",
    "age",
    "DebtRatio",
    "MonthlyIncome",
    "NumberOfOpenCreditLinesAndLoans"
]]

imputer = SimpleImputer(strategy="median")
X = imputer.fit_transform(X)



model = DecisionTreeClassifier(max_depth=5)
model.fit(X, y)


with open("model_bank.pkl", "wb") as f:
    pickle.dump((model, imputer), f)

print(" Modèle entraîné avec ton dataset")