import pickle
from pydantic import BaseModel
from fastapi import FastAPI
"""
app=FastAPI(title="Hello World API")
@app.get("/")
def read_root():
    return {"message":"Hello Worlf"}

"""
app = FastAPI(title="E-commerce BI & AI API")
class Item(BaseModel):
    name: str
    price: float
    in_stock: bool = True
    sales: int
    views: int
db = []
@app.post("/items/")
def create_item(item: Item):
    db.append(item)
    return {"message": "Item créé", "item": item}

@app.get("/items/{item_id}")
def read_item(item_id: int):
    if item_id < len(db):
        item = db[item_id]
        return item
    return {"error": "Item not found"}

@app.get("/items/")
def list_items():
    return {"items": db, "count": len(db)}

@app.get("/kpi/total_products")
def total_products():
    return {"total": len(db)}

@app.get("/kpi/total_value")
def total_value():
    total = sum(item.price for item in db)
    return {"total_value": total}

@app.get("/kpi/in_stock")
def in_stock_products():
    count = sum(1 for item in db if item.in_stock)
    return {"in_stock": count}

try:
    with open("model.pkl", "rb") as f:
        model = pickle.load(f)
except:
    model = None

@app.post("/predict")
def predict(item: Item):
    if model is None:
        return {"error": "Model not trained"}

    features = [[item.price, item.sales, item.views]]
    prediction = model.predict(features)[0]

    return {"prediction": prediction}