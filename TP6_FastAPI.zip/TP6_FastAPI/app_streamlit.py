import streamlit as st
import requests

st.title("💳 Dashboard Crédit")

st.header("Entrer les données du client")

credit_utilisation = st.number_input("Utilisation crédit", 0.0)
age = st.number_input("Age", 18)
debt_ratio = st.number_input("Debt Ratio", 0.0)
income = st.number_input("Revenu mensuel", 0.0)
credit_lines = st.number_input("Nombre de crédits", 0)

# Prediction
if st.button("Prédire"):
    data = {
        "credit_utilisation": credit_utilisation,
        "age": age,
        "debt_ratio": debt_ratio,
        "income": income,
        "credit_lines": credit_lines
    }

    res = requests.post("http://127.0.0.1:8000/predict", json=data)
    st.write(res.json())

# KPI
st.header("KPI")

if st.button("Afficher KPI"):
    st.write(requests.get("http://127.0.0.1:8000/kpi/total_clients").json())
    st.write(requests.get("http://127.0.0.1:8000/kpi/avg_income").json())
    st.write(requests.get("http://127.0.0.1:8000/kpi/default_rate").json())
    st.write(requests.get("http://127.0.0.1:8000/kpi/risky_clients").json())